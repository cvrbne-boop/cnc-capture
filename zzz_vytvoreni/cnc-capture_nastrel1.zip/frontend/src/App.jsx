import React from "react";
import Scanner from "./Scanner";

export default function App(){
  return (
    <div style={{padding:20}}>
      <h1>CNC Capture — Scanner</h1>
      <Scanner />
    </div>
  );
}
